/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import hospitalmangementsystem_.Patient;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author siyan
 */
public class HospitalTest {
    
    public HospitalTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
@BeforeEach
    void setUp() {
        service = new HospitalService();
    }

    // ----- Register a patient -----

    @Test
    void registerPatient_addsOutpatientSuccessfully() {
        Patient patient = new Patient("P001", "Thabo", "Nkosi", 34, "Male",
                "Flu", PatientCategory.OUTPATIENT);

        boolean result = service.registerPatient(patient);

        assertTrue(result);
        assertEquals(1, service.getTotalRegisteredPatients());
    }

    @Test
    void registerPatient_rejectsDuplicatePatientId() {
        Patient patient1 = new Patient("P001", "Thabo", "Nkosi", 34, "Male",
                "Flu", PatientCategory.OUTPATIENT);
        Patient patient2 = new Patient("P001", "Sipho", "Dube", 40, "Male",
                "Cold", PatientCategory.EMERGENCY);

        service.registerPatient(patient1);
        boolean result = service.registerPatient(patient2);

        assertFalse(result);
        assertEquals(1, service.getTotalRegisteredPatients());
    }

    // ----- Search for a patient -----

    @Test
    void findPatientById_returnsRegisteredPatient() {
        Patient patient = new Patient("P002", "Lindiwe", "Zulu", 28, "Female",
                "Sprained Ankle", PatientCategory.EMERGENCY);
        service.registerPatient(patient);

        Patient found = service.findPatientById("P002");

        assertNotNull(found);
        assertEquals("Lindiwe", found.getFirstName());
    }

    @Test
    void findPatientById_returnsNullWhenNotFound() {
        Patient found = service.findPatientById("DOES_NOT_EXIST");

        assertNull(found);
    }

    // ----- Update patient details -----

    @Test
    void updatePatient_changesDetailsForExistingPatient() {
        Patient patient = new Patient("P003", "Naledi", "Mokoena", 45, "Female",
                "Hypertension", PatientCategory.OUTPATIENT);
        service.registerPatient(patient);

        boolean updated = service.updatePatient("P003", "Naledi", "Mokoena", 46,
                "Female", "Hypertension - stable");

        assertTrue(updated);
        assertEquals(46, service.findPatientById("P003").getAge());
        assertEquals("Hypertension - stable", service.findPatientById("P003").getMedicalCondition());
    }

    @Test
    void updatePatient_returnsFalseForUnknownPatient() {
        boolean updated = service.updatePatient("UNKNOWN", "A", "B", 20, "Male", "None");

        assertFalse(updated);
    }

    // ----- Delete a patient -----

    @Test
    void deletePatient_removesExistingPatient() {
        Patient patient = new Patient("P004", "Kagiso", "Molefe", 50, "Male",
                "Fracture", PatientCategory.EMERGENCY);
        service.registerPatient(patient);

        boolean deleted = service.deletePatient("P004");

        assertTrue(deleted);
        assertNull(service.findPatientById("P004"));
        assertEquals(0, service.getTotalRegisteredPatients());
    }

    @Test
    void deletePatient_releasesBedWhenInpatientHadOne() {
        Inpatient inpatient = new Inpatient("P005", "Palesa", "Khumalo", 60, "Female", "Surgery recovery");
        service.registerPatient(inpatient);
        service.allocateBed("P005");
        String occupiedBed = inpatient.getBedNumber();
        assertNotNull(occupiedBed);

        service.deletePatient("P005");

        assertTrue(service.getWard().isBedAvailable(occupiedBed));
    }

    // ----- Allocate a bed -----

    @Test
    void allocateBed_succeedsForInpatient() {
        Inpatient inpatient = new Inpatient("P006", "Bongani", "Sithole", 38, "Male", "Pneumonia");
        service.registerPatient(inpatient);

        HospitalService.BedAllocationResult result = service.allocateBed("P006");

        assertTrue(result.isAllocated());
        assertNotNull(result.getBedNumber());
        assertEquals(result.getBedNumber(), inpatient.getBedNumber());
        assertEquals(1, service.getTotalOccupiedBeds());
    }

    @Test
    void allocateBed_failsForOutpatient() {
        Patient outpatient = new Patient("P007", "Zanele", "Ngcobo", 25, "Female",
                "Checkup", PatientCategory.OUTPATIENT);
        service.registerPatient(outpatient);

        HospitalService.BedAllocationResult result = service.allocateBed("P007");

        assertFalse(result.isAllocated());
    }

    @Test
    void allocateBed_failsWhenWardIsFull() {
        for (int i = 1; i <= Ward.TOTAL_BEDS; i++) {
            Inpatient inpatient = new Inpatient("F" + i, "First" + i, "Last" + i, 30, "Male", "Observation");
            service.registerPatient(inpatient);
            service.allocateBed("F" + i);
        }
        Inpatient extra = new Inpatient("F_EXTRA", "Extra", "Patient", 30, "Male", "Observation");
        service.registerPatient(extra);

        HospitalService.BedAllocationResult result = service.allocateBed("F_EXTRA");

        assertFalse(result.isAllocated());
        assertEquals(Ward.TOTAL_BEDS, service.getTotalOccupiedBeds());
    }

    // ----- Release a bed -----

    @Test
    void releaseBed_freesUpBedForDischargedInpatient() {
        Inpatient inpatient = new Inpatient("P008", "Tumi", "Radebe", 55, "Male", "Recovering");
        service.registerPatient(inpatient);
        service.allocateBed("P008");
        String bedNumber = inpatient.getBedNumber();

        boolean released = service.releaseBed("P008");

        assertTrue(released);
        assertNull(inpatient.getBedNumber());
        assertTrue(service.getWard().isBedAvailable(bedNumber));
        assertEquals(0, service.getTotalOccupiedBeds());
    }

    @Test
    void releaseBed_returnsFalseWhenNoBedAllocated() {
        Inpatient inpatient = new Inpatient("P009", "Amahle", "Cele", 33, "Female", "Observation");
        service.registerPatient(inpatient);

        boolean released = service.releaseBed("P009");

        assertFalse(released);
    }


