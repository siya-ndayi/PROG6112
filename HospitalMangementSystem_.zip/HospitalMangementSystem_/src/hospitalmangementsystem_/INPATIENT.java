/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hospitalmangementsystem_;

/**
 *
 * @author siyan
 */
class INPATIENT {
     private String ward;
    private String bedNumber;

    public INPATIENT(String patientID, String firstName, String lastName,
                     String gender, String medicalCondition,
                     String patientCategory, String ward) {

        

        this.ward = ward;
        this.bedNumber = "Not Allocated";
    }

    public String getWard() {
        return ward;
    }

    public String getBedNumber() {
        return bedNumber;
    }

    public void setBedNumber(String bedNumber) {
        this.bedNumber = bedNumber;
    }
          
     public void displayDetails(){
         
     System.out.println("Ward Number      : " );
        System.out.println("Bed Number       : " + bedNumber);
        System.out.println("--------------------------------------------");
        
         
     }
         
    
      }

