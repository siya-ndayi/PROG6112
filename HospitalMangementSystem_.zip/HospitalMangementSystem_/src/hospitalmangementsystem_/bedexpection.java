/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Exception.java to edit this template
 */
package hospitalmangementsystem_;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author siyan
 */
public class bedexpection extends Exception {
 
    public String allocateNextAvailableBed(Inpatient inpatient) throws WardFullException {
        Iterable<Bed[]> bedLayout = null;
        for (Bed[] row : bedLayout) {
            for (Bed bed : row) {
                if (!bed.isOccupied()) {
                    bed.allocate(inpatient.getPatientID());
                    inpatient.setBedNumber();
                    return bed.getBedID();
                }
            }
        }
        throw new WardFullException("Bed allocation failed: the ward is full (all " + TOTAL_BEDS + " beds are occupied).");
    }
    public void releaseBed(String bedID) throws InvalidBedException {
        Bed bed = findBed(bedID);
        if (bed == null) {
            throw new InvalidBedException("Bed " + bedID + " does not exist in this ward.");
        }
        if (!bed.isOccupied()) {
            throw new InvalidBedException("Bed " + bed.getBedID() + " is already available - nothing to release.");
        }
        bed.release();
    }
    /**
     * Creates a new instance of <code>bedexpection</code> without detail
     * message.
     */
    public bedexpection() {
        
    }
public List<Bed> getAvailableBeds() {
        List<Bed> available = new ArrayList<>();
        Iterable<Bed[]> bedLayout = null;
        for (Bed[] row : bedLayout) {
            for (Bed bed : row) {
                if (!bed.isOccupied()) {
                    available.add(bed);
                }
            }
        }
        return available;
    }
public List<Bed> getOccupiedBeds() {
        List<Bed> occupied = new ArrayList<>();
        for (Bed[] row : bedLayout) {
            for (Bed bed : row) {
                if (bed.isOccupied()) {
                    occupied.add(bed);
                }
            }
        }
        return occupied;
    }
       
       public int getOccupiedCount() {
        return getOccupiedBeds().size();
    }

    public int getAvailableCount() {
        return TOTAL_BEDS - getOccupiedCount();
    }

    public double getOccupancyPercentage() {
        return (getOccupiedCount() * 100.0) / TOTAL_BEDS;
    }
    
    /**
     * Constructs an instance of <code>bedexpection</code> with the specified
     * detail message.
     *
     * @param msg the detail message.
     */
    public bedexpection(String msg) {
        super(msg);
        
    }
public boolean occupied;
    public Patient patient;

     {
       
        this.occupied = false;
        this.patient = null;
    }
      
      public String getBedID() {
        return bedID;
    }

    public int getRow() {
        return row;
    }

    public int getCol() {
        return col;
    }

    public boolean isOccupied() {
        return occupied;
    }

    public String getPatientID() {
        return patientID;
    }
    private Bed findBed(String bedID) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private static class WardFullException extends Exception {

        public WardFullException() {
        }
    }
}
  