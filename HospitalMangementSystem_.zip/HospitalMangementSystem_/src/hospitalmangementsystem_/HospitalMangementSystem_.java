/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package hospitalmangementsystem_;
import java.util.Scanner;
import java.util.*;

/**
 *
 * @author siyan
 */
public class HospitalMangementSystem_ {
private static final Scanner scanner = new Scanner(System.in);
private static final int[] LIST_A_BEDS = {800, 801, 802, 807, 808, 809};
    private static final int[] LIST_B_BEDS = {803, 804, 805, 806, 810, 811, 812};
    private static final int[] LIST_C_BEDS = {813, 814, 815, 816, 817, 818, 820};

    private static final List<Patient> patients = new ArrayList<>();
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("********************************************");
        System.out.println("*     HOSPITAL MANAGEMENT SYSTEM           *");
        System.out.println("********************************************");
        System.out.println();
        
        System.out.println("********************************************");
        System.out.println("*     Patient Registration           *");
        System.out.println("********************************************");
        
        
        System.out.print("Enter Patient ID: ");
        String id = scanner.nextLine().trim();
         System.out.print("First Name: ");
        String fn = scanner.nextLine().trim();
        System.out.print("Last Name: ");
        String ln = scanner.nextLine().trim(); 
        
        System.out.print("Gender: ");
        String gender = scanner.nextLine().trim();
        System.out.print("Medical Condition: ");
        String cond = scanner.nextLine().trim();
        
        System.out.println("Patient registered successfully.");
        
        
       
        System.out.println("bed management");
        
        System.out.println("\n1. Allocate Bed");
        System.out.println("2. Release Bed");
        System.out.print("Select choice: ");
        System.out.println("Select Bed Category: ");
        System.out.println("1. List A (Beds 800-802, 807-809)");
        System.out.println("2. List B (Beds 803-806, 810-812)");
        System.out.println("3. List C (Beds 813-818, 820)");
        
        System.out.print("Enter Patient ID: ");
        String pId = scanner.nextLine().trim();
        System.out.println("Error: Patient not found.");
        System.out.println("Error: Patient already assigned to bed ");
        System.out.print("Enter Bed ID (e.g., B01): ");
        String bId = scanner.nextLine().trim().toUpperCase();
        
       System.out.println("Error: Bed ID does not exist in ward."); 
       System.out.println("Error: Bed " + bId + " is already occupied.");
       System.out.print("Enter Bed ID to release: ");
       System.out.println("Bed " + bId + " released successfully.");
       System.out.println("Error: Bed " + bId + " is not currently allocated.");
       
       System.out.println("===Hospital Report===");
       System.out.println("Total Registered Patients");
       System.out.println("Occupied Beds");
       System.out.println("Availble Beds");
       System.out.println("Bed Occupancy Percentage");
       

        
        System.out.println("1. Register a new patient");
        System.out.println("2. Search for a patient using Patient ID");
        System.out.println("3. Update a patient's details");
        System.out.println("4. Allocate a bed (Inpatient only)");
        System.out.println("5. Release a bed");
        System.out.println("6. Display complete ward layout");
        System.out.println("7. Display all registered patients");
        System.out.println("8. Display available beds");
        System.out.println("9. Display occupied beds");
        System.out.println("10. Display ward occupancy percentage");
        System.out.println("0. Exit");
        System.out.print("Enter choice: ");
        int choice = 0;
    
System.out.println("\n=================== MAIN MENU ===================");
        System.out.println("1. Patient Management");
        System.out.println("2. Bed Management");
        System.out.println("3. Reports");
        System.out.println("4. Exit");
        System.out.println("==================================================");
        
        System.out.println("\n------------- PATIENT MANAGEMENT MENU -------------");
            System.out.println("1. Register Patient");
            System.out.println("2. Search and Display Patient");
            System.out.println("3. Update Patient Details");
            System.out.println("4. Delete Patient");
            System.out.println("5. Display All Patients");
            System.out.println("6. Back to Main Menu");
            System.out.println("-----------------------------------------------------");
        
            
            System.out.println("\n-------------- BED MANAGEMENT MENU --------------");
            System.out.println("1. Allocate Next Available Bed to Inpatient");
            System.out.println("2. Allocate a Specific Bed to Inpatient");
            System.out.println("3. Release Bed (Discharge Patient)");
            System.out.println("4. Display Ward Bed Layout");
            System.out.println("5. Display Available Beds");
            System.out.println("6. Display Occupied Beds");
            System.out.println("7. Back to Main Menu");
            System.out.println("--------------------------------------------------");
    
            System.out.println("\n------------------ REPORTS MENU ------------------");
            System.out.println("1. Patient Report");
            System.out.println("2. Bed Occupancy Report");
            System.out.println("3. Display Patients Sorted by Surname");
            System.out.println("4. Display Patients Sorted by Patient ID");
            System.out.println("5. Back to Main Menu");
            System.out.println("---------------------------------------------------");
            
switch (choice) {
     case 1: registerPatient();     break;
                case 2: searchPatient();        break;
                case 3: updatePatient();        break;
                case 4: deletePatient();        break;
                case 0: System.out.println("Returning to Main Menu..."); break;
                default: System.out.println("Invalid choice.");
}
   



    }

    private static int[] getAllBeds() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private static boolean isBedOccupied(int bed) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
private void printMainMenu() {
        
    }

 
    private void patientManagementMenu() {
        
    }
    
    private static void registerPatient() {
          
    }
        
    
    
    private static void searchPatient() {
         System.out.print("Enter Patient ID to search: ");
        String id = scanner.nextLine().trim();
    }

    private static void updatePatient() {
        
    }

    private static void deletePatient() {
       System.out.println("\n--- Delete Patient ---");
        
        
        System.out.println("\n--- Available Beds ---");
        for (int bed : getAllBeds()) {
            if (!isBedOccupied(bed)) {
                System.out.print(bed + " ");
            }
        }
    }

    private int readInt(String enter_your_choice_) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void searchAndDisplayPatient() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void displayAllPatients() {
         System.out.println("\n--- Search Patient ---");
        String patientID = readString("Enter Patient ID to search: ");
        Patient patient = service.searchPatient(patientID);
        patient.displayDetails();
        System.out.println("No patients recorded.");
    }
    
    private void bedManagementMenu() {
        
    }

    private String readString(String enter_Patient_ID_to_search_) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private static class PatientNotFoundException {

        public PatientNotFoundException() {
        }

        private boolean getMessage() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }
    }
      
    }
    
    
  
    

