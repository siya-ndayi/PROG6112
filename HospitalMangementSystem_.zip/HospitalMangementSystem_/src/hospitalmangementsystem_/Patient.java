/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hospitalmangementsystem_;

/**
 *
 * @author siyan
 */
public class Patient {
    private String patientID;
    private String firstName;
    private String lastName;
    private String gender;
    private String medicalCondition;
    private String patientCategory;
    private String patientId;
    private PatientCategory category;
    private int age;
    
     public String getPatientId() {
        String patientId = null;
        return patientId;
    }

    public final void setPatientId(String patientId) {
        if (patientId == null || patientId.trim().isEmpty()) {
            throw new IllegalArgumentException("Patient ID cannot be empty.");
        }
        this.patientId = patientId.trim();
    }

    public String getFirstName() {
        return firstName;
    }

    public final void setFirstName(String firstName) {
        this.firstName = requireText(firstName, "First name");
    }

    public String getLastName() {
        return lastName;
    }

    public final void setLastName(String lastName) {
        this.lastName = requireText(lastName, "Last name");
    }
    public int getAge() {
        int age = 0;
        return age;
    }

    public final void setAge(int age) {
        if (age < 0 || age > 120) {
            throw new IllegalArgumentException("Age must be between 0 and 120.");
        }
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public final void setGender(String gender) {
        this.gender = requireText(gender, "Gender");
    }

    public String getMedicalCondition() {
        return medicalCondition;
    }

    public final void setMedicalCondition(String medicalCondition) {
        this.medicalCondition = requireText(medicalCondition, "Medical condition");
    }

    public PatientCategory getCategory() {
        PatientCategory category = null;
        return category;
    }

    public final void setCategory(PatientCategory category) {
        if (category == null) {
            throw new IllegalArgumentException("Patient category is required.");
        }
        this.category = category;
    }
    
     
      public void displayDetails() {
        System.out.println("--------------------------------------------");
        System.out.println("Patient ID       : " + patientId);
        System.out.println("First Name       : " + firstName);
        System.out.println("Last Name        : " + lastName);
        String age = null;
        System.out.println("Age              : " + age);
        System.out.println("Gender           : " + gender);
        System.out.println("Medical Condition: " + medicalCondition);
        System.out.println("Category         : " + category);
        System.out.println("--------------------------------------------");
    }

    private String requireText(String firstName, String first_name) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
